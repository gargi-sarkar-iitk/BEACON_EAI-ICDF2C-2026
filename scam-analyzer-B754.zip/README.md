# Scam Analyzer — cybercrime story classifier

This repository contains code, data, and checkpoints for a classifier that analyzes short "stories" describing cyber incidents and outputs the presence of attack stages and psychological tactics (20 labels total). The project was trained as a LoRA adapter on top of a Mistral base model and includes scripts for training, inference and evaluation.

## Project Structure

- `dataset/`: CSV datasets used for training and testing.
	- `cybercrime_dataset_1500.csv` — training dataset (labeled).
	- `testset.csv` — test / evaluation dataset.
- `scripts/` — runnable scripts:
	- `train_script.py` — prepares data and fine-tunes LoRA adapters using TRL/SFT.
	- `inference_script.py` — run single-shot inference with base or fine-tuned adapters.
	- `evaluation_script.py` — evaluate base vs fine-tuned adapters and generate `evaluation_results.tex`.
- `results_scam_analyzer_stable/` — training outputs and checkpoints.
	- `final_model/` — saved adapter + tokenizer for the fine-tuned model.
	- `checkpoint-*` — intermediate checkpoint directories.
- `evaluation_results.tex` — LaTeX table generator output (created by the evaluation script).

## Requirements

- Python 3.8+ with CUDA-enabled PyTorch if you want GPU inference/training.
- Recommended packages (install via `pip`): `transformers`, `peft`, `trl`, `bitsandbytes`, `datasets`, `torch`, `pandas`, `tqdm`, `scikit-learn`, `evaluate`.

It's recommended to create a virtual environment before installing dependencies:

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt   # if you have one; otherwise install the packages above
```

## Quickstart — Inference

Run inference using either the `base` model (no adapters) or the `finetuned` model (loads LoRA adapters saved under `results_scam_analyzer_stable/final_model`). Example:

```bash
# Use the fine-tuned adapters (default adapter path used by the script)
python scripts/inference_script.py --model_type finetuned

# Run the base model (no adapters)
python scripts/inference_script.py --model_type base

# If your adapters are stored elsewhere, pass --adapter_path
python scripts/inference_script.py --model_type finetuned --adapter_path ./results_scam_analyzer_stable/checkpoint-282
```

Notes:
- `inference_script.py` prints an example analysis for a demo story when run as-is. To call the `analyze_story` function programmatically, import it from the script or adapt it into your own runner.

## Training

Training uses `scripts/train_script.py`. It expects `dataset/cybercrime_dataset_1500.csv` to contain the labeled stories and reason columns. The script formats the dataset, applies LoRA via `peft` and trains using `trl.SFTTrainer`.

```bash
# Run training (script uses internal config values; adapt the script for custom args)
python scripts/train_script.py
```

Training configuration (a few important values are set in the script's `Config` class):
- Base model: `mistralai/Mistral-7B-Instruct-v0.2`
- Output directory: `./results_scam_analyzer_stable`
- LoRA: `r=32`, `alpha=64`, `dropout=0.05`
- Batch & optimization: configurable inside `train_script.py` (see `Config`).

After training, adapters and tokenizer are saved to `results_scam_analyzer_stable/final_model`.

## Evaluation

Run the evaluation script to compare the base model and the fine-tuned adapters across the testset. The script will compute per-label classification metrics and textual metrics (ROUGE / BLEU / BERTScore for explanation text), and will write a LaTeX table to `evaluation_results.tex`.

```bash
python scripts/evaluation_script.py --adapter_path ./results_scam_analyzer_stable/final_model --data_path dataset/testset.csv --num_samples 100
```

Adjust `--num_samples` to `-1` to evaluate on the full dataset.

## Notes & Tips

- GPU required: The code loads models with `device_map='auto'` and assumes CUDA is available. For CPU-only runs, adapt the scripts to avoid `.to('cuda')` and large quantized loads.
- Quantization: The repo uses 4-bit quantization (bitsandbytes) for memory efficiency during fine-tuning and inference — ensure `bitsandbytes` is installed and compatible with your system.
- Tokenizer: Tokenizer files are saved alongside adapters in `results_scam_analyzer_stable/final_model` after training.
- Parsing: The evaluation relies on a fairly strict textual format (blocks per label). If you change prompts, update the parser in `evaluation_script.py`.