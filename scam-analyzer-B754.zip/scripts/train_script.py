import os
import torch
import pandas as pd
from datasets import Dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
)
from trl import SFTConfig, SFTTrainer
from peft import LoraConfig, get_peft_model


class Config:
    MODEL_ID = "mistralai/Mistral-7B-Instruct-v0.2"
    DATA_PATH = "dataset/cybercrime_dataset_1500.csv"
    LORA_DROPOUT = 0.05
    LORA_TARGET_MODULES = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
    BNB_4BIT_QUANT_TYPE = "nf4"
    BNB_4BIT_COMPUTE_DTYPE = torch.bfloat16
    USE_4BIT = True
    USE_NESTED_QUANT = True
    
    OUTPUT_DIR = "./results_scam_analyzer_stable"

    NUM_TRAIN_EPOCHS = 3

    PER_DEVICE_TRAIN_BATCH_SIZE = 8 
    GRADIENT_ACCUMULATION_STEPS = 2 

    LEARNING_RATE = 5e-5
    LR_SCHEDULER_TYPE = "cosine"

    LORA_R = 32 
    LORA_ALPHA = 64

    MAX_SEQ_LENGTH = 4096

    OPTIM = "paged_adamw_32bit"
    SAVE_STEPS = 100
    LOGGING_STEPS = 10
    WEIGHT_DECAY = 0.001
    FP16 = True
    BF16 = False
    MAX_GRAD_NORM = 0.3
    MAX_STEPS = -1
    WARMUP_RATIO = 0.03
    GROUP_BY_LENGTH = True


PSYCH_LABELS = [
    "fear_and_intimidation", "phantom_riches", "authority_socialproof_impersonation",
    "urgency_and_scarcity", "consistency_and_reciprocity", "emotional_exploitation"
]
STAGE_LABELS = [
    "reconnaissance", "resource_development", "initial_contact", "detonation",
    "persistence", "escalation", "defense_evasion", "credential_harvesting",
    "discovery", "pivoting", "collection", "command_and_control",
    "exfiltration", "impact"
]
ALL_LABELS = STAGE_LABELS + PSYCH_LABELS

def create_prompt(story, target_analysis):
    system_prompt = (
        "Analyze the following story for stages of a cyber attack and psychological tactics. "
        "For each item in the provided list, classify if it is present and provide a brief "
        "reason based ONLY on the story."
    )
    return f"<s>[INST] {system_prompt}\n\nStory:\n{story} [/INST] {target_analysis} </s>"

def format_dataset(data_path):
    df = pd.read_csv(data_path)
    reason_column_mapping = {"reconnaissance": "Reconnaissance_Reason", "resource_development": "Resource_Development_Reason", "initial_contact": "Initial_Contact_Reason", "detonation": "Detonation_Reason", "persistence": "Persistence_Reason", "escalation": "Escalation_Reason", "defense_evasion": "Defense_Evasion_Reason", "credential_harvesting": "Credential_Harvesting_Reason", "discovery": "Discovery_Reason", "pivoting": "Pivoting_Reason", "collection": "Collection_Reason", "command_and_control": "Command_and_Control_Reason", "exfiltration": "Exfiltration_Reason", "impact": "Impact_Reason", "fear_and_intimidation": "Fear_and_Intimidation_Reason", "phantom_riches": "Phantom_Riches_Reason", "authority_socialproof_impersonation": "Authority_SocialProof_Impersonation_Reason", "urgency_and_scarcity": "Urgency_and_Scarcity_Reason", "consistency_and_reciprocity": "Consistency_and_Reciprocity_Reason", "emotional_exploitation": "Emotional_Exploitation_Reason"}
    error_value = "ERROR_GENERATION_FAILED"
    mask = df[list(reason_column_mapping.values())].apply(lambda x: x.astype(str).str.contains(error_value, na=False)).any(axis=1)
    df_filtered = df[~mask].copy()
    df_filtered.dropna(subset=['Story'], inplace=True)
    formatted_data = []
    for _, row in df_filtered.iterrows():
        story = row['Story']
        target_analysis = ""
        for label in ALL_LABELS:
            reason_col = reason_column_mapping[label]
            reason = str(row[reason_col])
            if pd.notna(row[reason_col]) and reason.strip() and reason.lower() != 'nan':
                present = "Yes"
                reason_text = reason.strip()
            else:
                present = "No"
                reason_text = "N/A"
            target_analysis += f"[{label}]\nPresent: {present}\nReason: {reason_text}\n\n"
        target_analysis = target_analysis.strip()
        formatted_data.append({"text": create_prompt(story, target_analysis)})
    return Dataset.from_list(formatted_data)

def main():
    print("Starting training process with STABLE configuration...")
    dataset = format_dataset(Config.DATA_PATH)
    if dataset is None: return

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=Config.USE_4BIT,
        bnb_4bit_quant_type=Config.BNB_4BIT_QUANT_TYPE,
        bnb_4bit_compute_dtype=Config.BNB_4BIT_COMPUTE_DTYPE,
        bnb_4bit_use_double_quant=Config.USE_NESTED_QUANT,
    )

    print(f"Loading base model: {Config.MODEL_ID}")
    model = AutoModelForCausalLM.from_pretrained(
        Config.MODEL_ID,
        quantization_config=bnb_config,
        device_map="auto"
    )
    model.config.use_cache = False
    model.config.pretraining_tp = 1

    tokenizer = AutoTokenizer.from_pretrained(Config.MODEL_ID, trust_remote_code=True)
    tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    peft_config = LoraConfig(
        lora_alpha=Config.LORA_ALPHA,
        lora_dropout=Config.LORA_DROPOUT,
        r=Config.LORA_R,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=Config.LORA_TARGET_MODULES
    )
    
    training_config = SFTConfig(
        output_dir=Config.OUTPUT_DIR,
        num_train_epochs=Config.NUM_TRAIN_EPOCHS,
        per_device_train_batch_size=Config.PER_DEVICE_TRAIN_BATCH_SIZE,
        gradient_accumulation_steps=Config.GRADIENT_ACCUMULATION_STEPS,
        optim=Config.OPTIM,
        save_steps=Config.SAVE_STEPS,
        logging_steps=Config.LOGGING_STEPS,
        learning_rate=Config.LEARNING_RATE,
        weight_decay=Config.WEIGHT_DECAY,
        fp16=Config.FP16,
        bf16=Config.BF16,
        max_grad_norm=Config.MAX_GRAD_NORM,
        max_steps=Config.MAX_STEPS,
        warmup_ratio=Config.WARMUP_RATIO,
        group_by_length=Config.GROUP_BY_LENGTH,
        lr_scheduler_type=Config.LR_SCHEDULER_TYPE,
        report_to="tensorboard",
        # max_seq_length=Config.MAX_SEQ_LENGTH,
        # dataset_text_field="text",
        packing=False,
    )

    trainer = SFTTrainer(
        model=model,
        train_dataset=dataset,
        peft_config=peft_config,
        # tokenizer=tokenizer,
        args=training_config,
    )

    print("Starting model training...")
    trainer.train()

    final_model_path = os.path.join(Config.OUTPUT_DIR, "final_model")
    print(f"Training finished. Saving adapters to {final_model_path}")
    trainer.model.save_pretrained(final_model_path)
    tokenizer.save_pretrained(final_model_path)
    
    print("Script finished successfully!")

if __name__ == "__main__":
    main()