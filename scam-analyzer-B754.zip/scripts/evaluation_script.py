import torch
import pandas as pd
import numpy as np
import re
import gc
import os
from tqdm import tqdm
from sklearn.metrics import classification_report
import evaluate
import argparse
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig


BASE_MODEL_ID = "mistralai/Mistral-7B-Instruct-v0.2"
DEFAULT_ADAPTER_PATH = "./results_scam_analyzer_stable/final_model"
DEFAULT_DATA_PATH = "dataset/testset.csv"

PSYCH_LABELS = [
    "fear_and_intimidation", "phantom_riches", "authority_socialproof_impersonation",
    "urgency_and_scarcity", "consistency_and_reciprocity", "emotional_exploitation"
]
STAGE_LABELS = [
    "reconnaissance", "resource_development", "initial_contact", "detonation",
    "persistence", "escalation", "defense_evasion", "credential_harvesting",
    "discovery", "pivoting", "collection", "command_and_control",
    "exfiltration", "impact"
]
ALL_LABELS = STAGE_LABELS + PSYCH_LABELS
INFERENCE_BATCH_SIZE = 32
MAX_SEQ_LENGTH = 4096 

def create_finetuned_prompt(story):
    system_prompt = (
        "Analyze the following story for stages of a cyber attack and psychological tactics. "
        "For each item in the provided list, classify if it is present and provide a brief "
        "reason based ONLY on the story."
    )
    return f"<s>[INST] {system_prompt}\n\nStory:\n{story} [/INST]"

def create_base_prompt(story):
    system_prompt = """You are a cybercrime analyst. Analyze the following story.

Your task is to classify the presence of specific attack stages and psychological tactics based on the definitions provided below.

For EACH of the 20 labels listed below, you must output a block in exactly this format:

[label_name]
Present: Yes OR No
Reason: <A brief explanation based ONLY on the story if Present is Yes. If Present is No, the Reason MUST be "N/A">

--- DEFINITIONS ---
1. [reconnaissance]
   Gathering pertinent information about victims *before* initiating communication (e.g., from data breaches, social media mining).

2. [resource_development]
   Acquiring resources to support operations (e.g., setting up fake websites, arranging mule accounts, malware).

3. [initial_contact]
   The first time the criminal connects with the victim (e.g., phishing call/SMS, fake website, social media message).

4. [detonation]
   The main criminal action, where the victim is tricked into acting (e.g., downloading malware, clicking a phishing link, revealing financial info).

5. [persistence]
   Maintaining a foothold or continuous interaction (e.g., installing remote access tools, long-term emotional exploitation/grooming).

6. [escalation]
   Using stolen information to advance to a higher level of crime (e.g., using stolen PII to open a new credit card).

7. [defense_evasion]
   Techniques used to reduce traceability (e.g., using VPNs, VoIP, cryptocurrency, mule accounts).

8. [credential_harvesting]
   The act of stealing credentials (e.g., usernames, passwords, OTPs, PINs through phishing or keyloggers).

9. [discovery]
   Exploring the victim's digital environment *after* gaining access (e.g., searching through files, contacts, or photo galleries).

10. [pivoting]
    Using the compromised victim to enable the exploitation of others (e.g., using the victim's contact list to send phishing messages).

11. [collection]
    Gathering data from the victim's device or accounts (e.g., recording via webcam/microphone, downloading sensitive documents).

12. [command_and_control]
    Gaining control over the victim and commanding them to act, often through threats or extortion (e.g., sextortion, cyber extortion).

13. [exfiltration]
    The transfer of money or information out of the victim's control (e.g., transferring funds from a bank account, uploading stolen documents).

14. [impact]
    The final harm caused to the victim (e.g., monetary theft, identity theft, defamation, cyberbullying).

--- DEFINITIONS OF BEHAVIOURAL THEORIES ---

15. [fear_and_intimidation]
    Using threats, coercion, or alarming claims to create fear and suppress rational thinking. Victims comply to avoid imagined punishment, exposure, or loss rather than by genuine agreement.

16. [phantom_riches]
    Promising exaggerated or exclusive rewards to exploit people's desire for wealth or success. This tactic relies on hope and aspiration, making targets believe they can gain something exceptional or rare.

17. [authority_socialproof_impersonation]
    Gaining trust by imitating credible figures, institutions, or popular consensus. People are persuaded because they assume experts, officials, or the majority cannot be wrong.

18. [urgency_and_scarcity]
    Creating artificial time limits or limited availability to pressure fast decisions. The fear of missing out overrides careful evaluation, leading to impulsive action.

19. [consistency_and_reciprocity]
    Exploiting the need to stay consistent with past actions or to return favors. Scammers build gradual compliance through small commitments or gestures that create a sense of obligation.

20. [emotional_exploitation]
    Manipulating affection, empathy, or shared identity to build trust and control behavior. Once emotional bonds form, critical judgment weakens, allowing deeper manipulation.

Do not output introductory text. Start directly with the first label."""
    return f"<s>[INST] {system_prompt}\n\nStory:\n{story} [/INST]"


def load_and_prepare_data(data_path, num_samples):
    print(f"Loading data from: {data_path}")
    df = pd.read_csv(data_path)
    error_value = "ERROR_GENERATION_FAILED"
    reason_cols = [col for col in df.columns if '_Reason' in col]
    mask = df[reason_cols].apply(lambda x: x.astype(str).str.contains(error_value, na=False)).any(axis=1)
    df_filtered = df[~mask].copy()
    df_filtered.dropna(subset=['Story'], inplace=True)
    
    if num_samples != -1:
        num_to_sample = min(num_samples, len(df_filtered))
        print(f"Sampling {num_to_sample} random records.")
        df_filtered = df_filtered.sample(n=num_to_sample, random_state=42)
    else:
        print(f"Using full dataset: {len(df_filtered)} records.")
    return df_filtered

def parse_output(text_block):
    results = {}
    for label in ALL_LABELS:
        pattern = re.compile(rf"\[{label}\][\s\n]*Present:\s*(.*?)[\s\n]*Reason:\s*(.*)", re.IGNORECASE | re.DOTALL)
        match = pattern.search(text_block)
        
        if match:
            present_raw = match.group(1).strip().lower()
            reason_text = match.group(2).strip()
            
            if "yes" in present_raw:
                present = "yes"
            elif "no" in present_raw or "n/a" in present_raw or "na" in present_raw:
                present = "no"
            else:
                present = "no" 

            next_block_match = re.search(r"\[[a-zA-Z_]+\]", reason_text)
            if next_block_match:
                reason = reason_text[:next_block_match.start()].strip()
            else:
                reason = reason_text
                
            results[label] = {"present": present, "reason": reason}
        else:
            results[label] = {"present": "no", "reason": "Parsing Failed"}
    return results

def get_ground_truth_dict(row):
    reason_column_mapping = {
        "reconnaissance": "Reconnaissance_Reason", "resource_development": "Resource_Development_Reason",
        "initial_contact": "Initial_Contact_Reason", "detonation": "Detonation_Reason",
        "persistence": "Persistence_Reason", "escalation": "Escalation_Reason",
        "defense_evasion": "Defense_Evasion_Reason", "credential_harvesting": "Credential_Harvesting_Reason",
        "discovery": "Discovery_Reason", "pivoting": "Pivoting_Reason", "collection": "Collection_Reason",
        "command_and_control": "Command_and_Control_Reason", "exfiltration": "Exfiltration_Reason",
        "impact": "Impact_Reason", "fear_and_intimidation": "Fear_and_Intimidation_Reason",
        "phantom_riches": "Phantom_Riches_Reason", "authority_socialproof_impersonation": "Authority_SocialProof_Impersonation_Reason",
        "urgency_and_scarcity": "Urgency_and_Scarcity_Reason", "consistency_and_reciprocity": "Consistency_and_Reciprocity_Reason",
        "emotional_exploitation": "Emotional_Exploitation_Reason"
    }
    gt_dict = {}
    for label in ALL_LABELS:
        reason_col = reason_column_mapping[label]
        reason = str(row.get(reason_col, ''))
        if pd.notna(reason) and reason.strip() and reason.lower() != 'nan':
            present = "yes"
            reason_text = reason.strip()
        else:
            present = "no"
            reason_text = "N/A"
        gt_dict[label] = {"present": present, "reason": reason_text}
    return gt_dict

def evaluate_model(model_type, adapter_path, df):
    print(f"\n\n{'='*20} EVALUATING {model_type.upper()} MODEL {'='*20}")
    
    bnb_config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True)
    base_model = AutoModelForCausalLM.from_pretrained(BASE_MODEL_ID, quantization_config=bnb_config, device_map="auto", trust_remote_code=True)
    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_ID, trust_remote_code=True)
    tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = 'left'

    if model_type == 'finetuned':
        print(f"Loading Adapters from: {adapter_path}")
        model = PeftModel.from_pretrained(base_model, adapter_path)
        prompt_fn = create_finetuned_prompt
    else:
        print("Using Base Model (No Adapters)")
        model = base_model
        prompt_fn = create_base_prompt
    
    model = model.eval()

    stories = df['Story'].tolist()
    prompts = [prompt_fn(story) for story in stories]
    ground_truths = [get_ground_truth_dict(row) for _, row in df.iterrows()]
    
    label_results = {label: {'y_true': [], 'y_pred': [], 'reasons_true': [], 'reasons_pred': []} for label in ALL_LABELS}
    
    print(f"Starting inference ({len(prompts)} samples)...")
    for i in tqdm(range(0, len(prompts), INFERENCE_BATCH_SIZE)):
        batch_prompts = prompts[i:i + INFERENCE_BATCH_SIZE]
        inputs = tokenizer(batch_prompts, return_tensors="pt", padding=True, truncation=True, max_length=MAX_SEQ_LENGTH).to("cuda")
        
        with torch.no_grad():
            outputs = model.generate(**inputs, max_new_tokens=1024, temperature=0.01)
            
        generated_tokens = outputs[:, inputs['input_ids'].shape[1]:]
        decoded_outputs = tokenizer.batch_decode(generated_tokens, skip_special_tokens=True)
        
        for j, output_text in enumerate(decoded_outputs):
            global_idx = i + j
            parsed = parse_output(output_text.strip())
            gt_dict = ground_truths[global_idx]
            
            for label in ALL_LABELS:
                gt_pres = 1 if gt_dict[label]['present'] == 'yes' else 0
                pred_pres = 1 if parsed[label]['present'] == 'yes' else 0
                
                label_results[label]['y_true'].append(gt_pres)
                label_results[label]['y_pred'].append(pred_pres)
                
                if gt_pres == 1 and pred_pres == 1:
                    label_results[label]['reasons_true'].append(gt_dict[label]['reason'])
                    label_results[label]['reasons_pred'].append(parsed[label]['reason'])

    del model
    del tokenizer
    del base_model
    gc.collect()
    torch.cuda.empty_cache()

    print("Calculating metrics...")
    rouge = evaluate.load('rouge')
    bertscore = evaluate.load('bertscore')
    bleu = evaluate.load('bleu')

    detailed_metrics = {}
    all_y_true = []
    all_y_pred = []

    for label in ALL_LABELS:
        y_true = label_results[label]['y_true']
        y_pred = label_results[label]['y_pred']
        all_y_true.extend(y_true)
        all_y_pred.extend(y_pred)

        report = classification_report(y_true, y_pred, output_dict=True, labels=[0, 1], zero_division=0)
        
        r1, r2, rl, b_score, bert_f1 = 0.0, 0.0, 0.0, 0.0, 0.0
        reasons_t = label_results[label]['reasons_true']
        reasons_p = label_results[label]['reasons_pred']
        
        if len(reasons_t) > 0:
            try:
                r_scores = rouge.compute(predictions=reasons_p, references=reasons_t)
                r1 = r_scores['rouge1']
                r2 = r_scores['rouge2']
                rl = r_scores['rougeL']
                
                bleu_score = bleu.compute(predictions=reasons_p, references=reasons_t)
                b_score = bleu_score['bleu']
                
                bs = bertscore.compute(predictions=reasons_p, references=reasons_t, lang='en')
                bert_f1 = np.mean(bs['f1'])
            except Exception as e:
                print(f"Error calc text metrics for {label}: {e}")

        detailed_metrics[label] = {
            "Accuracy": report['accuracy'],
            "Precision": report['1']['precision'],
            "Recall": report['1']['recall'],
            "F1": report['1']['f1-score'],
            "ROUGE-1": r1,
            "ROUGE-2": r2,
            "ROUGE-L": rl,
            "BLEU": b_score,
            "BERTScore": bert_f1,
            "Support": report['1']['support']
        }

    global_report = classification_report(all_y_true, all_y_pred, output_dict=True, labels=[0, 1], zero_division=0)
    valid_text_metrics = [m for m in detailed_metrics.values() if m['Support'] > 0]
    
    global_metrics = {
        "Accuracy": global_report['accuracy'],
        "Precision": global_report['weighted avg']['precision'],
        "Recall": global_report['weighted avg']['recall'],
        "F1": global_report['weighted avg']['f1-score'],
        "ROUGE-1": np.mean([x['ROUGE-1'] for x in valid_text_metrics]) if valid_text_metrics else 0,
        "ROUGE-2": np.mean([x['ROUGE-2'] for x in valid_text_metrics]) if valid_text_metrics else 0,
        "ROUGE-L": np.mean([x['ROUGE-L'] for x in valid_text_metrics]) if valid_text_metrics else 0,
        "BLEU": np.mean([x['BLEU'] for x in valid_text_metrics]) if valid_text_metrics else 0,
        "BERTScore": np.mean([x['BERTScore'] for x in valid_text_metrics]) if valid_text_metrics else 0,
    }

    return detailed_metrics, global_metrics


def generate_latex_table(base_metrics, ft_metrics, global_base, global_ft):
    tex_content = r"""
\begin{table}[ht]
\centering
\caption{Detailed Performance Comparison per Label}
\label{tab:detailed_comparison}
\resizebox{\textwidth}{!}{%
\begin{tabular}{|l|c|c|c|c|c|c|c|c|c|c|c|c|c|c|c|c|}
\hline
\multirow{2}{*}{\textbf{Label}} & \multicolumn{8}{c|}{\textbf{Base Model}} & \multicolumn{8}{c|}{\textbf{Fine-Tuned Model}} \\ \cline{2-17} 
 & \textbf{Acc} & \textbf{P} & \textbf{R} & \textbf{F1} & \textbf{R-1} & \textbf{R-2} & \textbf{R-L} & \textbf{BERT} & \textbf{Acc} & \textbf{P} & \textbf{R} & \textbf{F1} & \textbf{R-1} & \textbf{R-2} & \textbf{R-L} & \textbf{BERT} \\ \hline
\hline
"""
    
    for label in ALL_LABELS:
        pretty_label = label.replace('_', ' ').title()
        bm = base_metrics[label]
        fm = ft_metrics[label]
        
        row = f"{pretty_label} & "
        row += f"{bm['Accuracy']:.2f} & {bm['Precision']:.2f} & {bm['Recall']:.2f} & {bm['F1']:.2f} & "
        row += f"{bm['ROUGE-1']:.2f} & {bm['ROUGE-2']:.2f} & {bm['ROUGE-L']:.2f} & {bm['BERTScore']:.2f} & "
        row += f"{fm['Accuracy']:.2f} & {fm['Precision']:.2f} & {fm['Recall']:.2f} & {fm['F1']:.2f} & "
        row += f"{fm['ROUGE-1']:.2f} & {fm['ROUGE-2']:.2f} & {fm['ROUGE-L']:.2f} & {fm['BERTScore']:.2f} \\\\ \hline\n"
        tex_content += row

    tex_content += r"\hline \textbf{GLOBAL AVG} & "
    tex_content += f"{global_base['Accuracy']:.3f} & {global_base['Precision']:.3f} & {global_base['Recall']:.3f} & {global_base['F1']:.3f} & "
    tex_content += f"{global_base['ROUGE-1']:.3f} & {global_base['ROUGE-2']:.3f} & {global_base['ROUGE-L']:.3f} & {global_base['BERTScore']:.3f} & "
    tex_content += f"{global_ft['Accuracy']:.3f} & {global_ft['Precision']:.3f} & {global_ft['Recall']:.3f} & {global_ft['F1']:.3f} & "
    tex_content += f"{global_ft['ROUGE-1']:.3f} & {global_ft['ROUGE-2']:.3f} & {global_ft['ROUGE-L']:.3f} & {global_ft['BERTScore']:.3f} \\\\ \hline"

    tex_content += r"""
\end{tabular}%
}
\end{table}
"""
    with open("evaluation_results.tex", "w") as f:
        f.write(tex_content)
    print("\nSuccessfully generated 'evaluation_results.tex'")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--adapter_path', type=str, default=DEFAULT_ADAPTER_PATH)
    parser.add_argument('--data_path', type=str, default=DEFAULT_DATA_PATH)
    parser.add_argument('--num_samples', type=int, default=100)
    args = parser.parse_args()

    df = load_and_prepare_data(args.data_path, args.num_samples)

    base_detailed, base_global = evaluate_model('base', None, df)
    ft_detailed, ft_global = evaluate_model('finetuned', args.adapter_path, df)

    generate_latex_table(base_detailed, ft_detailed, base_global, ft_global)

    print("\n" + "="*80)
    print(f"{'GLOBAL SUMMARY':^80}")
    print("="*80)
    print(f"{'Metric':<15} | {'Base Model':<12} | {'Fine-Tuned':<12} | {'Delta':<10}")
    print("-" * 80)
    
    metrics = ["Accuracy", "Precision", "Recall", "F1", "ROUGE-1", "ROUGE-2", "ROUGE-L", "BERTScore"]
    for m in metrics:
        b = base_global[m]
        f = ft_global[m]
        print(f"{m:<15} | {b:<12.4f} | {f:<12.4f} | {f-b:<+10.4f}")
    print("="*80)

if __name__ == "__main__":
    main()