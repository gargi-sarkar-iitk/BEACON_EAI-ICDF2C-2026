import torch
import argparse
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

BASE_MODEL_ID = "mistralai/Mistral-7B-Instruct-v0.2"
DEFAULT_ADAPTER_PATH = "./results_scam_analyzer_stable/final_model"

PSYCH_LABELS = [
    "fear_and_intimidation", "phantom_riches", "authority_socialproof_impersonation",
    "urgency_and_scarcity", "consistency_and_reciprocity", "emotional_exploitation"
]
STAGE_LABELS = [
    "reconnaissance", "resource_development", "initial_contact", "detonation",
    "persistence", "escalation", "defense_evasion", "credential_harvesting",
    "discovery", "pivoting", "collection", "command_and_control",
    "exfiltration", "impact"
]
ALL_LABELS = STAGE_LABELS + PSYCH_LABELS

def load_model_and_tokenizer(model_type, adapter_path=None):
    """Loads the appropriate model (base or fine-tuned) based on arguments."""
    print(f"Loading the {model_type} model and tokenizer...")

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
    )

    base_model = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL_ID,
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=True,
    )

    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_ID, trust_remote_code=True)
    tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = 'left'

    if model_type == 'finetuned':
        if not adapter_path:
            raise ValueError("Adapter path must be provided for a fine-tuned model.")
        print(f"Applying LoRA adapters from: {adapter_path}")
        model = PeftModel.from_pretrained(base_model, adapter_path)
    else: # model_type == 'base'
        print("Using the base model without any adapters.")
        model = base_model

    model = model.eval()
    print("Model loaded successfully!")
    return model, tokenizer

def create_finetuned_prompt(story):
    """
    The concise prompt used during training.
    Relies on the model's 'muscle memory' of the task.
    """
    system_prompt = (
        "Analyze the following story for stages of a cyber attack and psychological tactics. "
        "For each item in the provided list, classify if it is present and provide a brief "
        "reason based ONLY on the story."
    )
    return f"<s>[INST] {system_prompt}\n\nStory:\n{story} [/INST]"

def create_base_prompt(story):
    """
    The 'Heavy' prompt for the Base Model.
    Includes definitions and strict formatting rules.
    """
    system_prompt = """You are a cybercrime analyst. Analyze the following story.

Your task is to classify the presence of specific attack stages and psychological tactics based on the definitions provided below.

For EACH of the 20 labels listed below, you must output a block in exactly this format:

[label_name]
Present: Yes OR No
Reason: <A brief explanation based ONLY on the story if Present is Yes. If Present is No, the Reason MUST be "N/A">

--- DEFINITIONS OF ATTACK STAGES ---

1. [reconnaissance]
   Gathering pertinent information about victims *before* initiating communication (e.g., from data breaches, social media mining).

2. [resource_development]
   Acquiring resources to support operations (e.g., setting up fake websites, arranging mule accounts, malware).

3. [initial_contact]
   The first time the criminal connects with the victim (e.g., phishing call/SMS, fake website, social media message).

4. [detonation]
   The main criminal action, where the victim is tricked into acting (e.g., downloading malware, clicking a phishing link, revealing financial info).

5. [persistence]
   Maintaining a foothold or continuous interaction (e.g., installing remote access tools, long-term emotional exploitation/grooming).

6. [escalation]
   Using stolen information to advance to a higher level of crime (e.g., using stolen PII to open a new credit card).

7. [defense_evasion]
   Techniques used to reduce traceability (e.g., using VPNs, VoIP, cryptocurrency, mule accounts).

8. [credential_harvesting]
   The act of stealing credentials (e.g., usernames, passwords, OTPs, PINs through phishing or keyloggers).

9. [discovery]
   Exploring the victim's digital environment *after* gaining access (e.g., searching through files, contacts, or photo galleries).

10. [pivoting]
    Using the compromised victim to enable the exploitation of others (e.g., using the victim's contact list to send phishing messages).

11. [collection]
    Gathering data from the victim's device or accounts (e.g., recording via webcam/microphone, downloading sensitive documents).

12. [command_and_control]
    Gaining control over the victim and commanding them to act, often through threats or extortion (e.g., sextortion, cyber extortion).

13. [exfiltration]
    The transfer of money or information out of the victim's control (e.g., transferring funds from a bank account, uploading stolen documents).

14. [impact]
    The final harm caused to the victim (e.g., monetary theft, identity theft, defamation, cyberbullying).

--- DEFINITIONS OF BEHAVIOURAL THEORIES ---

15. [fear_and_intimidation]
    Using threats, coercion, or alarming claims to create fear and suppress rational thinking. Victims comply to avoid imagined punishment, exposure, or loss rather than by genuine agreement.

16. [phantom_riches]
    Promising exaggerated or exclusive rewards to exploit people's desire for wealth or success. This tactic relies on hope and aspiration, making targets believe they can gain something exceptional or rare.

17. [authority_socialproof_impersonation]
    Gaining trust by imitating credible figures, institutions, or popular consensus. People are persuaded because they assume experts, officials, or the majority cannot be wrong.

18. [urgency_and_scarcity]
    Creating artificial time limits or limited availability to pressure fast decisions. The fear of missing out overrides careful evaluation, leading to impulsive action.

19. [consistency_and_reciprocity]
    Exploiting the need to stay consistent with past actions or to return favors. Scammers build gradual compliance through small commitments or gestures that create a sense of obligation.

20. [emotional_exploitation]
    Manipulating affection, empathy, or shared identity to build trust and control behavior. Once emotional bonds form, critical judgment weakens, allowing deeper manipulation.

------------------------------------------------------------
Do not output any introductory text or summary. Start directly with the first label [reconnaissance]."""

    return f"<s>[INST] {system_prompt}\n\nStory:\n{story} [/INST]"


def analyze_story(story_text, model, tokenizer, model_type):
    if model_type == 'base':
        print("Using DETAILED prompt strategy (Base Model Mode)")
        prompt = create_base_prompt(story_text)
    else:
        print("Using CONCISE prompt strategy (Fine-Tuned Mode)")
        prompt = create_finetuned_prompt(story_text)

    inputs = tokenizer(prompt, return_tensors="pt").to("cuda")

    print("Generating analysis...")
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=1536,
            do_sample=True,
            temperature=0.1,
            top_p=0.9,
            repetition_penalty=1.1,
        )
    
    generated_tokens = outputs[:, inputs['input_ids'].shape[1]:]
    analysis = tokenizer.decode(generated_tokens[0], skip_special_tokens=True)
    
    return analysis

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run inference with the base or a fine-tuned model.")
    parser.add_argument(
        '--model_type', 
        type=str, 
        required=True, 
        choices=['base', 'finetuned'],
        help="Specify which model to use: 'base' or 'finetuned'"
    )
    parser.add_argument(
        '--adapter_path',
        type=str,
        default=DEFAULT_ADAPTER_PATH,
        help="Path to the trained LoRA adapters. Only used if model_type is 'finetuned'."
    )
    args = parser.parse_args()

    adapter_to_load = args.adapter_path if args.model_type == 'finetuned' else None
    if args.model_type == 'base' and args.adapter_path != DEFAULT_ADAPTER_PATH:
        print("Warning: --model_type is 'base', so the provided --adapter_path will be ignored.")

    model, tokenizer = load_model_and_tokenizer(args.model_type, adapter_path=adapter_to_load)

    new_story = """A scammer contacted me on my professional Instagram, posing as a talent scout from a Berlin marketing firm. They praised my design portfolio and offered a lucrative brand ambassador contract. To proceed, they sent a link to a “secure artist portal” to sign an NDA. The site looked legitimate, so I logged in using my email and password. The next day, I was locked out of my Instagram and email. The scammer messaged me again, now threatening. They showed they had my password, claimed to have accessed my cloud drive, and said they created an explicit fake video using my photos. They threatened to send it to my followers, family, and clients unless I paid $2,500 in Bitcoin within 12 hours. I complied and sent them the money."""
    
    model_analysis = analyze_story(new_story, model, tokenizer, args.model_type)
    
    print_header = f"--- Analysis from '{args.model_type}' Model"
    if args.model_type == 'finetuned':
        print_header += f" (Adapters: {adapter_to_load})"
    print(f"\n{print_header} ---")
    
    print(model_analysis)